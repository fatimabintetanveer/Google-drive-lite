import ImageForm from '@/components/forms/ImageForm'
import React from 'react'

export default function upload() {
  return (
    <div>
        <ImageForm />
    </div>
  )
}
