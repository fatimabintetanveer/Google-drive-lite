const BACKEND_URL = 'http://127.0.0.1';

module.exports = { BACKEND_URL };